from django.db import models
from django.utils import timezone
from django.conf import settings
from quiz.models import Quiz  # Adjust based on your project structure
from assignment.models import Assignment  # Adjust based on your project structure
from django.core.exceptions import ValidationError  # Import ValidationError

class Assessment(models.Model):
    title = models.CharField(max_length=255)
    
    # Foreign keys to Quiz and Assignment (both optional)
    quiz = models.ForeignKey(Quiz, related_name='assessments', null=True, blank=True, on_delete=models.SET_NULL)
    assignment = models.ForeignKey(Assignment, related_name='assessments', null=True, blank=True, on_delete=models.SET_NULL)

    total_score = models.IntegerField(blank=True)
    
    created_at = models.DateTimeField(default=timezone.now)
    due_date = models.DateTimeField(null=True, blank=True)
    created_by = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.CASCADE, related_name='created_assessments')

    def __str__(self):
        return self.title

    def is_past_due(self):
        """Check if the due date has passed."""
        if self.due_date:
            return timezone.now() > self.due_date
        return False

    def clean(self):
        """
        Ensure that either a `quiz`, an `assignment`, or both are set.
        """
        if not self.quiz and not self.assignment:
            raise ValidationError("An assessment must include at least a quiz or an assignment.")

    class Meta:
        ordering = ['due_date', 'created_at']
